package iai.kit.edu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InitializerEAApplication{


    public static void main(String[] args) {
        SpringApplication.run(InitializerEAApplication.class, args);

    }


}