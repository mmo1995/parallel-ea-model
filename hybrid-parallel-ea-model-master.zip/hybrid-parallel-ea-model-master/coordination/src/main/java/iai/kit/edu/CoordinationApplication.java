package iai.kit.edu;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.IOException;

@SpringBootApplication
public class CoordinationApplication{


    public static void main(String[] args) {
        SpringApplication.run(CoordinationApplication.class, args);

    }


}
