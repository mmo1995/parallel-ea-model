package edu.kit.iai.gleam;
import java.util.List;
public class DistibutedChromosomeList {
	public String header;
	public String ChromosomsList;
	
	public String getHeader() {
		return header;
	}
	public void setHeader(String header) {
		this.header = header;
	}
	public String getChromosomsList() {
		return ChromosomsList;
	}
	public void setChromosomsList(String chromosomsList) {
		ChromosomsList = chromosomsList;
	}
	
}
