package edu.kit.iai.gleam;

import java.util.List;

public class ResultList {
	public Integer parentIndex;
	public Integer childIndex;
	public List<Double> Dlist;
	
	public Integer getParentIndex() {
		return parentIndex;
	}
	public void setParentIndex(Integer parentIndex) {
		this.parentIndex = parentIndex;
	}
	public Integer getChildIndex() {
		return childIndex;
	}
	public void setChildIndex(Integer childIndex) {
		this.childIndex = childIndex;
	}
	/*public List<Double> getDlist() {
		return Dlist;
	}
	public void setDlist(List<Double> dlist) {
		this.Dlist = dlist;
	}*/

}
